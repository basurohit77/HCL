package com.demo.flag.entity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "Continent")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Continent {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	//@SequenceGenerator(name="CONTINENT_ID_GENERATOR", sequenceName="CONTINENT_SEQ", allocationSize=1)
	//@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="CONTINENT_ID_GENERATOR")
	
	private long continent_id;
	@Column(name="name")
	private String continent;
	//@OneToMany(cascade=CascadeType.ALL, mappedBy="continent")
	@OneToMany(fetch=FetchType.LAZY, cascade=CascadeType.ALL)
	@JoinColumn(name="continent_id")
	private Collection<Countries> countries = new ArrayList<Countries>();
	
	public Continent() { 
		super();
	}
	
	public Continent(String continent, List<Countries> listofCountry) {
		
		super();
		this.continent=continent;
		this.countries=listofCountry;
		
	}
	
	public long getContinent_id() {
		return continent_id;
	}

	public void setContinent_id(long continent_id) {
		this.continent_id = continent_id;
	}

	public String getContinent() {
		return continent;
	}

	public void setContinent(String continent) {
		this.continent = continent;
	}

	public Collection<Countries> getCountries() {
		return countries;
	}

	public void setCountries(Collection<Countries> countries) {
		this.countries = countries;
	}
	
	

	
}
