package com.demo.flag.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "Country")
@JsonIgnoreProperties(ignoreUnknown = true)
@NamedNativeQuery(name="Countries.getCountryOfContinent", query="select * from Country where continent_id= :continent_id", resultClass=Countries.class)
//@NamedNativeQuery(name="getFlagOfACountry", query="select flag as countryFlag from Country where name= :name", resultClass=Countries.class)

public class Countries {
	
	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO)
	//@SequenceGenerator(name="COUNTRIES_ID_GENERATOR", sequenceName="COUNTRIES_SEQ", allocationSize=1)
	//@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="COUNTRIES_ID_GENERATOR")
	private long country_id;
	private String name;
	private String flag;
	
	@ManyToOne(fetch=FetchType.LAZY)
	//@NotFound(action=NotFoundAction.IGNORE) //hibernate annotation
	@JoinColumn(name="continent_id")
	@JsonIgnore
	private Continent continent;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public Continent getContinent() {
		return continent;
	}

	public void setContinent(Continent continent) {
		this.continent = continent;
	}

	public long getCountry_id() {
		return country_id;
	}

	public void setCountry_id(long country_id) {
		this.country_id = country_id;
	}
	
		
	
}
