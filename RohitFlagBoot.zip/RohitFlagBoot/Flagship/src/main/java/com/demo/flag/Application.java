package com.demo.flag;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.demo.flag.entity.Continent;
import com.demo.flag.entity.Countries;
import com.demo.flag.repository.ContinentRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootApplication
public class Application implements CommandLineRunner {
	private static final Logger logger = LoggerFactory.getLogger(Application.class);

	@Autowired
	ContinentRepository continentRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
	
	
	@Override
	public void run(String... strings) throws Exception {
				
		// read json and write to db
		ObjectMapper mapper = new ObjectMapper();
		TypeReference<List<Continent>> typeReference = new TypeReference<List<Continent>>(){};
		//InputStream inputStream = TypeReference.class.getResourceAsStream("/json/continents.json");
		File inputStream = new File("G://continents.json");

		
		try {
			List<Continent> conts = mapper.readValue(inputStream,typeReference);
			conts.forEach(cont -> {
				System.out.println(cont.getContinent());
				System.out.println(cont.getCountries().size());
				});
			conts.forEach(cont1 -> {
				if(cont1.getContinent().toString().equalsIgnoreCase("ASIA")){
				List<Countries> listofcountry= cont1.getCountries().stream()
						.filter(c -> c.getName().equalsIgnoreCase("INDIA"))
						.map(c -> c)
						.collect(Collectors.toList());
				listofcountry.forEach(country -> {
					    System.out.println("Nane of the Country: " +country.getName());
					    System.out.println("Symbol of the Flag: " +country.getFlag());
				});
				}
			 });	
		
			continentRepository.save(conts);
			logger.info("SAVE: continents Saved!" );
			logger.info("Result: For Africa: " + continentRepository.getContinentByContinent("Africa"));
			//System.out.println("continents Saved!");
			
		   } catch (IOException e){
			   logger.info("FAIL: Unable to save in continentRepository" + e.getMessage());
			//System.out.println("Unable to save in continentRepository" + e.getMessage());
		}
		
		
	}
	
}
