package com.demo.flag.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.flag.entity.Continent;

public interface ContinentRepository extends JpaRepository<Continent,Long> {
	Continent getContinentByContinent(String continent);
}

