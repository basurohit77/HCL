package com.demo.flag.component;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.flag.entity.Continent;
import com.demo.flag.entity.Countries;
import com.demo.flag.repository.ContinentRepository;
import com.demo.flag.repository.CountriesRepository;

@Service
public class ContinentComponent {
	private static final Logger logger = LoggerFactory.getLogger(ContinentComponent.class);
	private EntityManager em;
	private ContinentRepository continentRepository;
	private CountriesRepository countriesRepository;
	
	public ContinentComponent(){
		
	}
	
	@Autowired
    public ContinentComponent(ContinentRepository continentRepository, CountriesRepository countriesRepository, EntityManager em){
		this.continentRepository=continentRepository;
		this.countriesRepository=countriesRepository;
		this.em=em;
		
	}

	public Continent getContinent(String name){
		logger.info("Looking for particular continent continentName "+ name );
		
		return (Continent)continentRepository.getContinentByContinent(name);
	}
	
	public List<String> getAllContinent(){
		logger.info("Looking for list of continentName " );
		List<Continent> listofContinents= continentRepository.findAll();
		List<String> listofContinentName= listofContinents.stream()
				.map(c -> c.getContinent())
				.collect(Collectors.toList());
	   return listofContinentName;
		
	}
	
	public List getListofCountries(String name){
		
		Continent continent = this.getContinent(name);
		logger.info("Looking for List of country with continentName "+ name );
		logger.info("Looking for List of country with continentName "+ continent.getContinent_id());
		
		
		//WITH JAVA POJO CLASS PROPERTY (Best Approach)
		List<Countries> listofCount0= (List<Countries>) continent.getCountries();
		return listofCount0;
		
		
		/*
		// WITH DSL GRAMMER (If not possible in Best Approach)
		List<Countries> listofCount1= countriesRepository.getCountriesByContinent(continent);
		return listofCount1;
		*/
		
		/*
		 //WITH NAME NATIVE QUERY (If not possible in DSL Grammar)
		Query query = em.createNamedQuery("Countries.getCountryOfContinent", Countries.class);
		query.setParameter("continent_id", continent.getContinent_id());
		return query.getResultList();
	  */

		
	}
	
	public Iterable<Continent> save(List<Continent> continents) {
        return continentRepository.save(continents);
    }
	
}
