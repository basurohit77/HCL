package com.demo.flag.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.flag.entity.Continent;
import com.demo.flag.entity.Countries;

public interface CountriesRepository extends JpaRepository<Countries,Long> {
	
	List<Countries> getCountriesByContinent(Continent continent);
	

}

