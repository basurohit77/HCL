package com.demo.flag.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.flag.component.ContinentComponent;
import com.demo.flag.entity.Continent;
import com.demo.flag.entity.Countries;

@RestController
@CrossOrigin
@RequestMapping("/flag")
public class FlagController {
	ContinentComponent continentComponent;
	
	@Autowired
	FlagController(ContinentComponent continentComponent){
	 this.continentComponent = continentComponent;
	}
	
	@RequestMapping("/getallcontinent")
	List<String> getAllContinent(){
		return continentComponent.getAllContinent();
	}
	
	@RequestMapping("/getallcountry")
	List<Countries> getListofCountries(@RequestParam(value="continent") String continent){
		List listofCount= continentComponent.getListofCountries(continent);
		return listofCount;
	}
	
	

}
